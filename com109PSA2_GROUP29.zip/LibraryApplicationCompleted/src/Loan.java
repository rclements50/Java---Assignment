import java.time.format.DateTimeFormatter;
import java.time.LocalDate;

public abstract class Loan{
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    protected LocalDate currentDate;
    private LocalDate issueDate, dueDate;
    private int renews = 0;
    private String barcode, userId;
    
    public Loan(String barcode, String userId, String issueDate, String dueDate,
            String renews){ //Constructor for loans being read in from .csv file
        this.barcode = barcode;
        this.userId = userId;//Calls on parent class constructor
        this.issueDate=LocalDate.parse(issueDate, format);
        this.dueDate=LocalDate.parse(dueDate, format);
        this.renews=Integer.parseInt(renews); 
    }
    
    public Loan(String barcode, String userId){//Overloaded constructor allows for new loans to be processed differently.
        this.barcode = barcode;
        this.userId = userId;
        this.issueDate = issueDate.now();
        this.renews = 0;
    }
    
    public void setDueDate(){ //Overridden
        this.dueDate = null;
    }
    
    public void displayLoan(){ //Overridden
        System.out.println(barcode + "\t" + userId + "\t" + format.format(issueDate) + "\t" + format.format(dueDate) + "\t" + renews);    
    }
    
    public int getRenews(){ //Getter for renews
        return renews;
    }
    
    public String getLoanCode(){ //Getter for barcode
        return barcode;
    }
    
    public String getUserId(){ //Getter for user ID
        return userId;
    }
    
    public LocalDate getDueDate(){ //Getter for due Date
        return dueDate;
    }
    
    public void updateDueDate(){ //Overridden
        this.dueDate = null;
    }
    
    public void updateRenews(){ //Overridden
        renews++;
    }
    
    public boolean checkDate(){ //Overridden
        if (currentDate.now().isBefore(dueDate)|| currentDate.now().isEqual(dueDate)){
            return true;
        }
        else return false;
    }
    
    public String toPrint(){ //Overridden
        return barcode + "," + userId+ "," + format.format(issueDate) + "," + format.format(dueDate) + "," + renews;
    }
    
    public LocalDate getIssueDate(){ //Getter for Issue Date
        return issueDate;
    }
    
    public void checkRenews(){ //Overridden
    }
}
