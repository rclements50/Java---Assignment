import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Multimedia extends Loan{ //Child of Loan class
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private LocalDate dueDate;
    private int MAX_RENEWS = 2; //Used for maxiumum renews
    
    //Constructor to take in loans being read in from csv
    public Multimedia(String barcode, String userId, String issueDate, String dueDate, String renews){
        super (barcode, userId, issueDate, dueDate, renews); //Calls parent constructor
        this.setDueDate(); //Assigns due date as this is item type specific
    }
    
    //Constructor to take in loans being created during program operation
    public Multimedia(String barcode, String userId){//Overloaded constructor allows for new loans to be processed differently.
        super(barcode, userId);
    }
    
    public void updateDueDate(){ //Updates due date by one week
        this.dueDate = dueDate.plusWeeks(1);
    }
    
    public void setDueDate(){ //Sets due date by one week
        this.dueDate = this.getIssueDate().plusWeeks(1);
    }
    
    public void displayLoan(){ //Overrides parent and displays loan
        System.out.println(this.getLoanCode() + "\t" + this.getUserId() + "\t" + format.format(this.getIssueDate()) + "\t" + format.format(dueDate) + "\t" + this.getRenews());    
    }
    
    public String toPrint(){ //Overides parent and returns string that can be written to file
        return this.getLoanCode() + "," + this.getUserId()+ "," + format.format(this.getIssueDate()) + "," + format.format(dueDate) + "," + this.getRenews();
    }
    
    public LocalDate getDueDate(){ //Getter for due Date
        return dueDate;
    }
    
    public boolean checkDate(){ //Overrides parent, checks if date is before or on due date
        if (currentDate.now().isBefore(dueDate)|| currentDate.now().isEqual(dueDate)){
            return true;
        }
        else return false;
    }
    
    public void checkRenews(){ //Checks current renews again Max renews variable
        if(this.getRenews()>= MAX_RENEWS){ //Outputs error message
            System.out.println("Too many renews! Multimedia can have no more than 2 renews. Please return by due date: " + format.format(dueDate));
        }
        else{ //Starts process of renewing loan
            System.out.println("Renewing");
            this.updateRenews();
            this.updateDueDate();
            System.out.println("New due date: " + format.format(dueDate)); //Prints new due date for loan
        }
    }
}