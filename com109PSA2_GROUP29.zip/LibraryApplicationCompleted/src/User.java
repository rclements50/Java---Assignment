public class User {
    private String userId, firstName, lastName, email;
    
    //Constructor to create new instance of User, read in from csv
    public User(String userId, String firstName, String lastName, String email){
        this.userId = userId;
        this.firstName= firstName;
        this.lastName = lastName;
        this.email = email; 
    }
    
    public String getUserId(){ //Getter for User Id
        return userId;
    }
}
