import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Book extends Loan{ //Child of Loan class
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private LocalDate dueDate;
    private int MAX_RENEWS = 3;
    
    //Constructor for intake of loans being read in from 
    public Book(String barcode, String userId, String issueDate, String dueDate, String renews){
        super (barcode, userId, issueDate, dueDate, renews); //Calls parent class constructor
        this.setDueDate();
    }
    
    public Book(String barcode, String userId){//Overloaded constructor allows for new loans to be processed differently.
        super(barcode, userId);
    }
    
    public void updateDueDate(){ //Updates due date by two weeks
        this.dueDate = dueDate.plusWeeks(2);
    }
    
    public void setDueDate(){ //Sets due date as four weeks from current date
        this.dueDate = this.getIssueDate().plusWeeks(4);
    }
    
    public void displayLoan(){ //Overrides parent method, displays loan
        System.out.println(this.getLoanCode() + "\t" + this.getUserId() + "\t" + format.format(this.getIssueDate()) + "\t" + format.format(dueDate) + "\t" + this.getRenews());    
    }
    
    public String toPrint(){ //Overrides parent, returns printable string for writing to file
        return this.getLoanCode() + "," + this.getUserId()+ "," + format.format(this.getIssueDate()) + "," + format.format(dueDate) + "," + this.getRenews();
    }
    
    public LocalDate getDueDate(){ //Getter for due Date
        return dueDate;
    }
    
    public boolean checkDate(){ //Checks if date is before or on due date
        if (currentDate.now().isBefore(dueDate)|| currentDate.now().isEqual(dueDate)){
            return true;
        }
        else return false;
    }
    
    public void checkRenews(){ //Checks current renews against max
        if(this.getRenews()>= MAX_RENEWS){ //Outputs error if too many
            System.out.println("Too many renews! Books can have no more than 3 renews. Please return by due date: " + format.format(dueDate));
        }
        else{ //Renews if appropriate
            System.out.println("Renewing");
            this.updateRenews();
            this.updateDueDate();
            System.out.println("New due date: " + format.format(dueDate));
        }
    }
}
