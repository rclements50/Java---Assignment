public class Item {
    private String barcode, author, title, type, year, isbn;
    
    //Constructor to create new item instance.
    public Item(String barcode, String author, String title, 
            String type, String year, String isbn){
        this.barcode = barcode;
        this.author = author;
        this.title = title;
        this.type = type;
        this.year = year;
        this.isbn = isbn;
    }
    
    //Displays item in formatted collumns
    public void displayItem(){//https://stackoverflow.com/questions/39312589/aligning-columns
        System.out.printf("%-15s%-22s%-42s%-22s%-22s%-12s\n",barcode,author,title,type,year ,isbn); //Prints formated objects
    }
    
    public String getItemCode(){ //Getter for barcode
        return barcode;
    }
    
    public String getType(){ //Getter for item type
        return type;
    }
}
